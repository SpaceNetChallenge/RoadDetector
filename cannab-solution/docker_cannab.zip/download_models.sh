wget https://s3.us-east-2.amazonaws.com/vdurnov/nn_models.zip -O /wdata/nn_models.zip
unzip -o /wdata/nn_models.zip -d /wdata
/bin/bash