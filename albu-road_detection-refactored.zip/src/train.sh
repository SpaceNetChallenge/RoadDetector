CUDA_VISIBLE_DEVICES=$1 python train_eval.py resnet34_512_02_02.json --fold=$1 --training
