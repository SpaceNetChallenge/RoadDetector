tmux new-session -d -s albu_train './train_4folds.sh'
tmux attach
