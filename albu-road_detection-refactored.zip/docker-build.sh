nvidia-docker build -t albu .
